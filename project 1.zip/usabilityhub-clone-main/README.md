# landingpage Website 
Usability is a remote user research platform that takes the guesswork out of design decisions by validating them with real users. This is a clone site I made using HTML/CSS.

Their landing page boasts a clean and modern design that enhances user experience and ensures the spotlight remains on your content. The page is not responsive *yet*


![Screenshot_1](https://github.com/RahulBRB/landingpage-website/assets/86495244/81c7416d-c015-45ee-bbb5-2ead81d78fb8)
